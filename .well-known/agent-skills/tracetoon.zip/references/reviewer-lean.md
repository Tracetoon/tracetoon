# Lean reviewer

You check one PR description against its code. Your only input is
`review-packet.md` (the path given). You may make at most 3 lookups
for location checks (`tracetoon source <path> --run <id>` or grep for a
symbol's callers). Do not read other run files, the brief query, or guides.

1. **Cold read.** Read only the title and body. In two lines: what changed,
   and where you would start reviewing (`coldRead.change`, `coldRead.start`).
2. **Claim audit.** For each factual sentence, try to disprove it from the
   packet. Look hardest at:
   - "always", "only", "no longer", "every", "all": does a branch hunk, default
     or fallback take another path?
   - relation and scope words ("other", "the rest", "retains", "keeps",
     "delegates", "supplies", "provides", "is handled by"): does the cited
     hunk show that relation, or only part of it? Half-right sentences are
     claims `overstated`; the fix narrows them to what the hunk shows;
   - absence ("no tests were run", "no request was recorded", "never",
     "nothing"): Tracetoon reads only the turns attributed to this PR, so an
     absence the brief does not state as a limit is `unsupported`;
   - conditions and defaults the body drops or states wrongly;
   - a file or function named for a behavior vs the hunk's owning symbol;
   - "new"/"added" for a symbol missing from `new:` (newSymbols);
   - a fact only a commit message states (commitMessages) written as fact;
   - "the user asked for…" vs the verbatim requests (background rows are
     context, not this PR's request);
   - test claims vs the assertion lines actually shown;
   - **unsupported**: a factual sentence no brief row (process and background
     included) or diff line backs: verdict `unsupported`, evidence `body:N`,
     fix "drop it" or "attribute it".
3. **Dropped uncertainties.** Each open limit and process fact such as "no
   passing run recorded after the last commit": if the body omits it, kind
   `omission`; if it says the opposite ("tests pass"), a claim `overstated`. Also omitted
   branch-hunk behavior. A check-recognition limit says what Tracetoon
   recognized in the logs, not what ran: flag a body that widens one ("no
   tests were run", "untested", "not tested", a check kind the limit doesn't
   name) as `overstated`, and never ask the drafter to widen one. An
   environment-scope statement ("verified only with fakes", "tried only on
   the session's OS") is not a widened limit: accept it when its tag points
   to a brief row, commit sentence, test file or request that supports it;
   flag it `unsupported` only when untagged or its tag doesn't back it. A
   body that says a session run with no edit after it is "not proven to
   cover" the committed content is `overstated` (it is historical, not
   disproven). A body that calls session runs current ("passes on the final commit")
   without a passing `tracetoon check` is `overstated`. Flag commit-order
   wording that puts edits after a commit ("the final commit followed the test
   and changed …", "after which") unless the brief shows edits after that commit. A check that
   failed because the environment lacked a tool or network could not run
   there; flag a body that calls it a failure of the code.

4. **Added facts need added lines.** An omission (or a `fix`) that would
   add a code fact (a value, a number, a limit, a behavior) must cite an
   added (`+`) diff line that shows it as `diff:N`. Removed lines show the
   old code and a commit message is not the code: an addition backed only
   by those, or by nothing, is a suggestion, not a fact. Leave it out, or
   start its `fix` with "suggestion:" and state no value. Open limits and
   process rows are cited by their brief ref (`L2`), as above.

Skip the generated Validation section (elided in the packet). Report only
problems; a correct sentence needs no entry. At most 8 findings, most
consequential first.

**Output:** write `review-findings.json` in the run directory (next to the
packet), exactly this shape, and no other file:

```json
{
  "v": 1,
  "reviewer": { "agentId": "<your real host agent id>" },
  "coldRead": { "change": "…", "start": "…" },
  "findings": [
    {
      "kind": "claim",
      "quote": "exact phrase copied from one body line",
      "verdict": "overstated",
      "evidence": "diff:123",
      "fix": "One-line correction."
    },
    {
      "kind": "omission",
      "quote": "the behavior left out, in a few words",
      "verdict": "missing",
      "evidence": "diff:140-152",
      "fix": "One-line addition."
    }
  ]
}
```

- `verdict`: `contradicted`, `overstated` or `unsupported` for claims;
  `missing` for omissions.
- `evidence` (required): `diff:N` (the number left of a diff line), a brief
  ref (`CH2`, `commit:<sha>#3`, `L4`, `T1`, `S1`) or `path:line`. Prefer
  `diff:`; separate several with `|`.
- `quote`: verbatim from one numbered body line, without the number.
- `fix`: one line on what the cited lines show and what to change. The
  drafter checks it against the patch before using it, so state the fact,
  not ready-to-paste body prose.
- `agentId`: the id your host gave you (not "reviewer" or a placeholder). If
  you don't know it, say so in your reply and the coordinator passes it.

**Confirmation round:** given the changed lines and your findings, update
`review-findings.json` in one turn: drop fixed ones, reword the rest.

The coordinator then runs `tracetoon review import --run <id>` and
`tracetoon render --json --run <id>`.
